import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'IoTControlPage.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Firebase initialization with Web options
  await Firebase.initializeApp(
    options: const FirebaseOptions(
      apiKey: "AIzaSyBzZqJawJgtj8keplGGfXkjGRQK9YUPgK0",
      appId: "1:759063470834:android:4401caeab0427b9bc8a66b",
      messagingSenderId: "759063470834",
      projectId: "btlon-mot",
      databaseURL:
          "https://btlon-mot-default-rtdb.firebaseio.com",
      storageBucket: "btlon-mot.firebasestorage.app",
    ),
  );

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: 'IoT Control',
      home: IoTControlPage(),
    );
  }
}
