import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';

class IoTControlPage extends StatefulWidget {
  const IoTControlPage({super.key});

  @override
  State<IoTControlPage> createState() => _IoTControlPageState();
}

class _IoTControlPageState extends State<IoTControlPage> {
  final DatabaseReference _dbRef = FirebaseDatabase.instance.ref(); // Kết nối tới Firebase
  bool isLedOn = false;
  bool isBuzzerOn = false;
  double ledBrightness = 50.0;
  bool isSyncingFromFirebase = false; // Biến kiểm soát việc đồng bộ

  @override
  void initState() {
    super.initState();
    _syncFromFirebase(); // Đồng bộ dữ liệu từ Firebase khi ứng dụng khởi động
  }

  // Hàm đồng bộ dữ liệu từ Firebase
  void _syncFromFirebase() {
    _dbRef.child('devices/led/isOn').onValue.listen((event) {
      final data = event.snapshot.value;
      if (!isSyncingFromFirebase) { // Đảm bảo không đồng bộ lại khi đang thay đổi giá trị
        setState(() {
          isLedOn = (data == 'true');
          if (!isLedOn) {
            ledBrightness = 0.0; // Tắt LED thì giảm độ sáng về 0
          }
        });
      }
    });

    _dbRef.child('devices/led/brightness').onValue.listen((event) {
      final data = event.snapshot.value;
      if (!isSyncingFromFirebase) {
        setState(() {
          ledBrightness = (data as num).toDouble();
        });
      }
    });

    _dbRef.child('devices/buzzer/isOn').onValue.listen((event) {
      final data = event.snapshot.value;
      if (!isSyncingFromFirebase) {
        setState(() {
          isBuzzerOn = (data == 'true');
        });
      }
    });
  }

  // Hàm cập nhật trạng thái lên Firebase
  void _updateFirebase() {
    // Cập nhật lại trạng thái LED lên Firebase
    _dbRef.child('devices/led').update({
      'isOn': isLedOn ? 'true' : 'false',  // Cập nhật đúng kiểu giá trị (true/false)
      'brightness': ledBrightness.toInt(),
    });

    // Cập nhật trạng thái Buzzer lên Firebase
    _dbRef.child('devices/buzzer').update({
      'isOn': isBuzzerOn ? 'true' : 'false',
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('IoT LED & Buzzer Control'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'LED On/Off',
                  style: TextStyle(fontSize: 16),
                ),
                Switch(
                  value: isLedOn,
                  onChanged: (value) {
                    setState(() {
                      isSyncingFromFirebase = true; // Đánh dấu việc đồng bộ bắt đầu
                      isLedOn = value;
                      if (isLedOn) {
                        ledBrightness = 100.0; // Đặt độ sáng tối đa khi bật LED
                      } else {
                        ledBrightness = 0.0; // Tắt LED thì đặt độ sáng về 0
                      }
                    });
                    _updateFirebase();
                    Future.delayed(const Duration(milliseconds: 500), () {
                      setState(() {
                        isSyncingFromFirebase = false; // Đồng bộ xong
                      });
                    });
                  },
                ),
              ],
            ),
            const SizedBox(height: 16),
            const Text(
              'LED Brightness',
              style: TextStyle(fontSize: 16),
            ),
            Slider(
              value: ledBrightness,
              min: 0,
              max: 100,
              divisions: 100,
              label: '${ledBrightness.toInt()}%',
              onChanged: isLedOn
                  ? (value) {
                      setState(() {
                        ledBrightness = value;
                        _updateFirebase();  // Cập nhật Firebase ngay khi thay đổi độ sáng
                      });
                    }
                  : null, // Vô hiệu hóa khi LED tắt
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Buzzer On/Off',
                  style: TextStyle(fontSize: 16),
                ),
                Switch(
                  value: isBuzzerOn,
                  onChanged: (value) {
                    setState(() {
                      isBuzzerOn = value;
                    });
                    _updateFirebase();
                  },
                ),
              ],
            ),
            const SizedBox(height: 32),
            Card(
              elevation: 2,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Control Data:',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    Text('LED State: ${isLedOn ? 'ON' : 'OFF'}'),
                    Text('LED Brightness: ${ledBrightness.toInt()}%'),
                    Text('Buzzer State: ${isBuzzerOn ? 'ON' : 'OFF'}'),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
